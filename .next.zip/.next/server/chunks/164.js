exports.id = 164;
exports.ids = [164];
exports.modules = {

/***/ 6149:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 1232, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 2987, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 6926, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 4282, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 6505, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 6061, 23))

/***/ }),

/***/ 1415:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 3380, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 954, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 8724));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 5091));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 3285))

/***/ }),

/***/ 8334:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  oV: () => (/* reexport */ biryani),
  jY: () => (/* reexport */ logo)
});

// UNUSED EXPORTS: headSliderImg

;// CONCATENATED MODULE: ./src/app/assets/background-burgers-home-top.jpeg
/* harmony default export */ const background_burgers_home_top = ({"src":"/_next/static/media/background-burgers-home-top.50d61744.jpeg","height":926,"width":1920,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAQACAMBIgACEQEDEQH/xAAnAAEBAAAAAAAAAAAAAAAAAAAABgEBAAAAAAAAAAAAAAAAAAAABP/aAAwDAQACEAMQAAAAjAN//8QAGxABAAEFAQAAAAAAAAAAAAAAARIABAUREyH/2gAIAQEAAT8Ax7zsyHktK1//xAAXEQADAQAAAAAAAAAAAAAAAAAAAUFx/9oACAECAQE/AK9P/8QAFxEBAAMAAAAAAAAAAAAAAAAAAQBBcf/aAAgBAwEBPwCjCf/Z","blurWidth":8,"blurHeight":4});
;// CONCATENATED MODULE: ./src/app/assets/menus/biryani.webp
/* harmony default export */ const biryani = ({"src":"/_next/static/media/biryani.3d8d7a00.webp","height":886,"width":1200,"blurDataURL":"data:image/webp;base64,UklGRloAAABXRUJQVlA4IE4AAACwAQCdASoIAAYAAkA4JQBOgB6K51loAP7tIWfnO+Xr1Yu+cCeD6MhLvV6wUaSVFD5sV0pFHcMj6gZl3rbXiVCdiBGgleb1JlYIQ+SZAAA=","blurWidth":8,"blurHeight":6});
;// CONCATENATED MODULE: ./src/app/assets/logo.jpeg
/* harmony default export */ const logo = ({"src":"/_next/static/media/logo.61b0ca03.jpeg","height":641,"width":644,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAgACAMBIgACEQEDEQH/xAAnAAEBAAAAAAAAAAAAAAAAAAAABgEBAAAAAAAAAAAAAAAAAAAABP/aAAwDAQACEAMQAAAAgAdH/8QAGxAAAgMAAwAAAAAAAAAAAAAAAgMEERIAIsH/2gAIAQEAAT8AjLSEFslsVRCTOpZvNeXz/8QAGBEBAQADAAAAAAAAAAAAAAAAAQIAESH/2gAIAQIBAT8AiS29rykz/8QAGhEAAQUBAAAAAAAAAAAAAAAAAQACERIhMf/aAAgBAwEBPwAuiuDi/9k=","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./src/app/assets/index.js






/***/ }),

/***/ 8526:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ layout)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(6786);
// EXTERNAL MODULE: ./src/app/globals.css
var globals = __webpack_require__(5023);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(4178);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(5124);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: ./node_modules/next/dist/compiled/react/react.shared-subset.js
var react_shared_subset = __webpack_require__(2947);
// EXTERNAL MODULE: ./src/app/assets/index.js + 3 modules
var assets = __webpack_require__(8334);
// EXTERNAL MODULE: ./node_modules/react-icons/ti/index.esm.js
var index_esm = __webpack_require__(831);
// EXTERNAL MODULE: ./node_modules/react-icons/ai/index.esm.js
var ai_index_esm = __webpack_require__(1436);
;// CONCATENATED MODULE: ./src/app/components/Header.jsx







function Header() {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "container z-0 flex flex-row items-center p-3 m-auto space-x-10",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                    src: assets/* logo */.jY,
                    className: "w-32"
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                    className: "flex flex-col space-x-6 text-xl sm:flex-row lg:flex-row xl:flex-row 2xl:flex-row font-extralight",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                href: "/",
                                children: "Home"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                href: "/about",
                                children: "About Us"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                href: "/menu",
                                children: "Menu"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                href: "/contact",
                                children: "Contact Us"
                            })
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                    className: "flex flex-row items-center space-x-2",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            className: "text-lg",
                            children: "| Follow Us:"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                            children: /*#__PURE__*/ jsx_runtime_.jsx(index_esm/* TiSocialFacebook */.E_e, {
                                size: 30
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                            children: /*#__PURE__*/ jsx_runtime_.jsx(ai_index_esm/* AiFillInstagram */.t0C, {
                                size: 30
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                            children: /*#__PURE__*/ jsx_runtime_.jsx(ai_index_esm/* AiFillYoutube */.b1v, {
                                size: 30
                            })
                        })
                    ]
                })
            })
        ]
    });
}
/* harmony default export */ const components_Header = (Header);

;// CONCATENATED MODULE: ./src/app/components/Footer.jsx




function Footer() {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "bg-red-950",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "container flex flex-col m-auto sm:flex-row xl:flex-row 2xl:flex-row",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "p-5 sm:w-1/2 lg:w-1/2 xl:w-1/2 2xl:w-1/2 w-1/1",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                className: "text-3xl font-bold",
                                children: "About Sara's Kitchen"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "Sara's Kitchen warmly welcomes you to indulge in the rich and flavorful culinary heritage of Karachi. Drawing inspiration from the bustling streets and vibrant markets of the city, we specialize in serving authentic home-cooked delights that capture the essence of traditional Pakistani cuisine."
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                className: "flex flex-row items-center space-x-2",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "text-lg",
                                        children: "Follow Us:"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(index_esm/* TiSocialFacebook */.E_e, {
                                            size: 30
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(ai_index_esm/* AiFillInstagram */.t0C, {
                                            size: 30
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(ai_index_esm/* AiFillYoutube */.b1v, {
                                            size: 30
                                        })
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "p-5 sm:w-1/4 lg:w-1/4 xl:w-1/4 2xl:w-1/4 w-1/1",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                className: "text-lg font-bold",
                                children: "Menus"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        children: "Desi Foods"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        children: "Chineese Foods"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        children: "Italian Foods"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        children: "American Foods"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        children: "Turkish Foods"
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "p-5 sm:w-1/4 lg:w-1/4 xl:w-1/4 2xl:w-1/4 w-1/1",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                className: "text-lg font-bold",
                                children: "Useful Links"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        children: "Home"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        children: "About Us"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        children: "Menus"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        children: "Traditional Foods"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        children: "Our Speciality"
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "p-5 sm:w-1/4 lg:w-1/4 xl:w-1/4 2xl:w-1/4 w-1/1",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                className: "text-lg font-bold",
                                children: "Company Info"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        children: "Privacy Policy"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        children: "Terms Of Use"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        children: "Food Delivery"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        children: "Complain"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        children: "Get Help"
                                    })
                                ]
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "text-center",
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                        children: [
                            "\xa9 ",
                            new Date().getFullYear(),
                            " Sara's Kitchen. All rights reserved."
                        ]
                    })
                })
            })
        ]
    });
}
/* harmony default export */ const components_Footer = (Footer);

// EXTERNAL MODULE: ./node_modules/react-icons/md/index.esm.js
var md_index_esm = __webpack_require__(7193);
// EXTERNAL MODULE: ./node_modules/react-icons/bs/index.esm.js
var bs_index_esm = __webpack_require__(8976);
// EXTERNAL MODULE: ./node_modules/react-icons/bi/index.esm.js
var bi_index_esm = __webpack_require__(4274);
;// CONCATENATED MODULE: ./src/app/components/TopBar.jsx





function TopBar() {
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "p-2 bg-[#682d0b]",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "container flex flex-col items-center content-center justify-between m-auto sm:flex-row xl:flex-row 2xl:flex-row lg:flex-row",
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "flex flex-col items-center space-x-2 sm:flex-row lg:flex-row xl:flex-row 2xl:flex-row",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "flex flex-row items-center content-center space-x-1",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(md_index_esm/* MdEmail */.ixJ, {}),
                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    children: "info@saras-kitchen.com"
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "flex flex-row items-center content-center space-x-1",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(bs_index_esm/* BsTelephoneFill */.UL8, {}),
                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    children: "+92 312 262 9392"
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "flex flex-row items-center content-center space-x-1 sm:flex-row lg:flex-row xl:flex-row 2xl:flex-row",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(bi_index_esm/* BiSolidMap */.oNx, {}),
                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            children: "Phase 2 Ext. DHA"
                        })
                    ]
                })
            ]
        })
    });
}
/* harmony default export */ const components_TopBar = (TopBar);

;// CONCATENATED MODULE: ./src/app/layout.js





const Layout = ({ children })=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("html", {
        lang: "en",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("body", {
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(components_TopBar, {}),
                /*#__PURE__*/ jsx_runtime_.jsx(components_Header, {}),
                /*#__PURE__*/ jsx_runtime_.jsx("main", {
                    children: children
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(components_Footer, {})
            ]
        })
    });
};
/* harmony default export */ const layout = (Layout);


/***/ }),

/***/ 5091:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/background-burgers-home-top.50d61744.jpeg","height":926,"width":1920,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAQACAMBIgACEQEDEQH/xAAnAAEBAAAAAAAAAAAAAAAAAAAABgEBAAAAAAAAAAAAAAAAAAAABP/aAAwDAQACEAMQAAAAjAN//8QAGxABAAEFAQAAAAAAAAAAAAAAARIABAUREyH/2gAIAQEAAT8Ax7zsyHktK1//xAAXEQADAQAAAAAAAAAAAAAAAAAAAUFx/9oACAECAQE/AK9P/8QAFxEBAAMAAAAAAAAAAAAAAAAAAQBBcf/aAAgBAwEBPwCjCf/Z","blurWidth":8,"blurHeight":4});

/***/ }),

/***/ 8724:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/logo.61b0ca03.jpeg","height":641,"width":644,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAgACAMBIgACEQEDEQH/xAAnAAEBAAAAAAAAAAAAAAAAAAAABgEBAAAAAAAAAAAAAAAAAAAABP/aAAwDAQACEAMQAAAAgAdH/8QAGxAAAgMAAwAAAAAAAAAAAAAAAgMEERIAIsH/2gAIAQEAAT8AjLSEFslsVRCTOpZvNeXz/8QAGBEBAQADAAAAAAAAAAAAAAAAAQIAESH/2gAIAQIBAT8AiS29rykz/8QAGhEAAQUBAAAAAAAAAAAAAAAAAQACERIhMf/aAAgBAwEBPwAuiuDi/9k=","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 3285:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/biryani.3d8d7a00.webp","height":886,"width":1200,"blurDataURL":"data:image/webp;base64,UklGRloAAABXRUJQVlA4IE4AAACwAQCdASoIAAYAAkA4JQBOgB6K51loAP7tIWfnO+Xr1Yu+cCeD6MhLvV6wUaSVFD5sV0pFHcMj6gZl3rbXiVCdiBGgleb1JlYIQ+SZAAA=","blurWidth":8,"blurHeight":6});

/***/ }),

/***/ 3881:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(85);
/* harmony import */ var next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0__);
  

  /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((props) => {
    const imageData = {"type":"image/x-icon","sizes":"16x16"}
    const imageUrl = (0,next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0__.fillMetadataSegment)(".", props.params, "favicon.ico")

    return [{
      ...imageData,
      url: imageUrl + "",
    }]
  });

/***/ }),

/***/ 5023:
/***/ (() => {



/***/ })

};
;