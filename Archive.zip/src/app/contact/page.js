import React from 'react'
import Contact from '../components/Contact'





function page() {

  
  return (
    <div>
        <Contact />
    </div>
  )
}

export default page