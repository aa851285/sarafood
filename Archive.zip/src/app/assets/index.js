import headSliderImg from "./background-burgers-home-top.jpeg";
import biryaniImg from "./menus/biryani.webp"
import logo from "./logo.jpeg"

export {
    headSliderImg,
    biryaniImg,
    logo
};