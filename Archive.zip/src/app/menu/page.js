import React from 'react'
import HomeMenu from '../components/HomeMenu'

export default function page() {
  return (
    <div>
      <HomeMenu />
    </div>
  )
}
